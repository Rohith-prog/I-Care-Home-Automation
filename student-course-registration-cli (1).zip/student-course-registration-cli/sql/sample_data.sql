
INSERT INTO students(name, email) VALUES
('Rohith Karnati','rohith@example.com'),
('Aisha Patel','aisha@example.com');

INSERT INTO courses(code, title, capacity) VALUES
('CS101','Intro to Programming', 3),
('CS201','Data Structures', 2),
('CS301','Databases', 2);
