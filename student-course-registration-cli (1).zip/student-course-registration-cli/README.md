
# Student Course Registration System (CLI) — Java + JDBC + MySQL

A clean, menu-driven CLI application that demonstrates **persistent SQL storage** (MySQL), **robust input validation & exception handling**, and **admin automation** (bulk imports, CSV reports).

## ✨ Features
- Add/List **Students** & **Courses** (capacity-aware)
- **Enroll** / **Drop** students from courses (prevents duplicates, enforces capacity)
- **View** student schedule & course rosters
- **Admin automation**: bulk import courses from CSV, export **enrollment report** to CSV (reduces manual work)
- Clear validation & friendly error messages

## 🧱 Tech
Java 11 • JDBC • MySQL • HikariCP (connection pooling) • Maven

---

## 🚀 Quick Start
1) **Create DB**
```sql
CREATE DATABASE registration_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
```
2) **Apply schema & sample data**
```bash
mysql -u <user> -p registration_db < sql/schema.sql
mysql -u <user> -p registration_db < sql/sample_data.sql
```
3) **Configure DB**
- Copy `resources/db.properties.sample` → `resources/db.properties`
- Edit `db.url`, `db.user`, `db.password`

4) **Build & Run**
```bash
mvn -q package
java -cp target/registration-cli.jar com.rohithk.registration.Main
```
(Or run directly via `mvn -q exec:java` if you add the exec plugin.)

---

## 📊 Admin Automation
- `Admin → Export enrollment report (CSV)` → writes `enrollment_report.csv` in project root
- `Admin → Bulk import courses from CSV` → reads `resources/courses_import.csv`

---

## 📁 Project Structure
```
student-course-registration-cli
 ├─ src/
 │   ├─ com/rohithk/registration/
 │   │   ├─ Main.java                 # CLI menus
 │   │   ├─ db/                       # Connection & migrations
 │   │   │   └─ Database.java
 │   │   ├─ dao/                      # DAOs (JDBC)
 │   │   │   ├─ StudentDao.java
 │   │   │   ├─ CourseDao.java
 │   │   │   └─ EnrollmentDao.java
 │   │   ├─ model/                    # POJOs
 │   │   │   ├─ Student.java
 │   │   │   ├─ Course.java
 │   │   │   └─ Enrollment.java
 │   │   ├─ service/                  # Business logic
 │   │   │   ├─ StudentService.java
 │   │   │   ├─ CourseService.java
 │   │   │   └─ EnrollmentService.java
 │   │   ├─ util/                     # Validation & IO helpers
 │   │   │   ├─ Input.java
 │   │   │   ├─ Validators.java
 │   │   │   └─ Csvs.java
 │   │   └─ AppException.java         # friendly error type
 ├─ resources/
 │   ├─ db.properties.sample
 │   └─ courses_import.csv
 ├─ sql/
 │   ├─ schema.sql
 │   └─ sample_data.sql
 ├─ pom.xml
 ├─ .gitignore
 └─ README.md
```

---

## 🧪 Sample CLI Flow
- Admin → Add Course (sets capacity)  
- Student → Add Student  
- Enrollment → Enroll Student in Course (blocks over-capacity & duplicates)  
- Reports → Export CSV

---

## 📤 Upload to GitHub (step-by-step)
```bash
git init
git add .
git commit -m "feat: CLI Student Registration (JDBC + MySQL)"
git branch -M main
git remote add origin https://github.com/<your-username>/<repo-name>.git
git push -u origin main
```

---

## ⚠️ Notes
- JDBC URL format (example): `jdbc:mysql://localhost:3306/registration_db?useSSL=false&allowPublicKeyRetrieval=true&serverTimezone=UTC`
- In production, move secrets to environment variables or a vault.
