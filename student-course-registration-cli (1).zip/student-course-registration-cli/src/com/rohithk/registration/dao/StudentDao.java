
package com.rohithk.registration.dao;

import com.rohithk.registration.db.Database;
import com.rohithk.registration.model.Student;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class StudentDao {

    public Student add(String name, String email) throws SQLException {
        String sql = "INSERT INTO students(name,email) VALUES(?,?)";
        try (Connection con = Database.getConnection();
             PreparedStatement ps = con.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            ps.setString(1, name.trim());
            ps.setString(2, email.toLowerCase().trim());
            ps.executeUpdate();
            try (ResultSet rs = ps.getGeneratedKeys()) {
                rs.next();
                return new Student(rs.getInt(1), name, email.toLowerCase());
            }
        }
    }

    public Optional<Student> findByEmail(String email) throws SQLException {
        String sql = "SELECT id,name,email FROM students WHERE email=?";
        try (Connection con = Database.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, email.toLowerCase());
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return Optional.of(new Student(rs.getInt("id"), rs.getString("name"), rs.getString("email")));
                }
                return Optional.empty();
            }
        }
    }

    public List<Student> list() throws SQLException {
        String sql = "SELECT id,name,email FROM students ORDER BY id";
        try (Connection con = Database.getConnection();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            List<Student> out = new ArrayList<>();
            while (rs.next()) out.add(new Student(rs.getInt(1), rs.getString(2), rs.getString(3)));
            return out;
        }
    }
}
