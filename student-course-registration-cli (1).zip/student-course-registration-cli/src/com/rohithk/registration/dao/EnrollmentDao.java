
package com.rohithk.registration.dao;

import com.rohithk.registration.db.Database;

import java.io.FileWriter;
import java.io.IOException;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class EnrollmentDao {

    public void enroll(int studentId, int courseId) throws SQLException {
        String dupCheck = "SELECT 1 FROM enrollments WHERE student_id=? AND course_id=?";
        String insert = "INSERT INTO enrollments(student_id,course_id) VALUES(?,?)";
        try (Connection con = Database.getConnection()) {
            con.setAutoCommit(false);
            try (PreparedStatement psDup = con.prepareStatement(dupCheck)) {
                psDup.setInt(1, studentId);
                psDup.setInt(2, courseId);
                try (ResultSet rs = psDup.executeQuery()) {
                    if (rs.next()) throw new SQLIntegrityConstraintViolationException("Duplicate enrollment");
                }
            }
            try (PreparedStatement ps = con.prepareStatement(insert)) {
                ps.setInt(1, studentId);
                ps.setInt(2, courseId);
                ps.executeUpdate();
            }
            con.commit();
        }
    }

    public boolean drop(int studentId, int courseId) throws SQLException {
        String sql = "DELETE FROM enrollments WHERE student_id=? AND course_id=?";
        try (Connection con = Database.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, studentId);
            ps.setInt(2, courseId);
            return ps.executeUpdate() > 0;
        }
    }

    public List<String[]> courseRoster(int courseId) throws SQLException {
        String sql = "SELECT s.id, s.name, s.email FROM enrollments e JOIN students s ON e.student_id=s.id WHERE e.course_id=? ORDER BY s.name";
        try (Connection con = Database.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, courseId);
            try (ResultSet rs = ps.executeQuery()) {
                List<String[]> rows = new ArrayList<>();
                while (rs.next()) rows.add(new String[]{ String.valueOf(rs.getInt(1)), rs.getString(2), rs.getString(3)});
                return rows;
            }
        }
    }

    public void exportEnrollmentReportCsv(String path) throws SQLException, IOException {
        String sql = "SELECT c.code, c.title, c.capacity, COUNT(e.id) AS enrolled " +
                     "FROM courses c LEFT JOIN enrollments e ON c.id=e.course_id " +
                     "GROUP BY c.id ORDER BY c.code";
        try (Connection con = Database.getConnection();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery();
             FileWriter fw = new FileWriter(path)) {
            fw.write("code,title,capacity,enrolled,available\n");
            while (rs.next()) {
                int capacity = rs.getInt("capacity");
                int enrolled = rs.getInt("enrolled");
                int avail = Math.max(capacity - enrolled, 0);
                fw.write(String.format("%s,%s,%d,%d,%d\n",
                        rs.getString("code"), rs.getString("title").replace(',', ' '), capacity, enrolled, avail));
            }
        }
    }
}
