
package com.rohithk.registration;

import java.sql.*;

public class StudentDAO {
    public void registerStudent(String name, String email, String password) {
        try (Connection conn = DBConnection.getConnection()) {
            String sql = "INSERT INTO students (name, email, password) VALUES (?, ?, ?)";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setString(1, name);
            stmt.setString(2, email);
            stmt.setString(3, password);
            stmt.executeUpdate();
            System.out.println("✅ Student registered successfully!");
        } catch (SQLException e) {
            System.out.println("⚠️ Error registering student: " + e.getMessage());
        }
    }

    public Student login(String email, String password) {
        try (Connection conn = DBConnection.getConnection()) {
            String sql = "SELECT * FROM students WHERE email = ? AND password = ?";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setString(1, email);
            stmt.setString(2, password);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                return new Student(rs.getInt("id"), rs.getString("name"),
                                   rs.getString("email"), rs.getString("password"));
            }
        } catch (SQLException e) {
            System.out.println("⚠️ Error logging in: " + e.getMessage());
        }
        return null;
    }
}
