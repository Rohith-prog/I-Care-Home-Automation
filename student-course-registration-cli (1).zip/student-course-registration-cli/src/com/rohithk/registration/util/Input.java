
package com.rohithk.registration.util;

import java.util.Scanner;

public class Input {
    private final Scanner sc = new Scanner(System.in);

    public String prompt(String label) {
        System.out.print(label + ": ");
        return sc.nextLine();
    }
}
