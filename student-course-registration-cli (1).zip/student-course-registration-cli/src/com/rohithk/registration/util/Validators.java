
package com.rohithk.registration.util;

public class Validators {
    public static int requireInt(String raw, String field) {
        try { return Integer.parseInt(raw.trim()); }
        catch (Exception e) { throw new IllegalArgumentException(field + " must be a number"); }
    }
}
