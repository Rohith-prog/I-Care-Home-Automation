
package com.rohithk.registration.util;

import java.io.FileWriter;
import java.io.IOException;
import java.util.List;

public class Csvs {
    public static void write(String path, List<String[]> rows) throws IOException {
        try (FileWriter fw = new FileWriter(path)) {
            for (String[] r : rows) {
                fw.write(String.join(",", r));
                fw.write("\n");
            }
        }
    }
}
