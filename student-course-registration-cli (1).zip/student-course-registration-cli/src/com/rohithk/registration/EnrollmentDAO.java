
package com.rohithk.registration;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class EnrollmentDAO {
    public void enrollStudent(int studentId, int courseId) {
        try (Connection conn = DBConnection.getConnection()) {
            String sql = "INSERT INTO enrollments (student_id, course_id) VALUES (?, ?)";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setInt(1, studentId);
            stmt.setInt(2, courseId);
            stmt.executeUpdate();
            System.out.println("✅ Enrollment successful!");
        } catch (SQLException e) {
            System.out.println("⚠️ Error enrolling student: " + e.getMessage());
        }
    }

    public List<Integer> getEnrolledCourses(int studentId) {
        List<Integer> courses = new ArrayList<>();
        try (Connection conn = DBConnection.getConnection()) {
            String sql = "SELECT course_id FROM enrollments WHERE student_id = ?";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setInt(1, studentId);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                courses.add(rs.getInt("course_id"));
            }
        } catch (SQLException e) {
            System.out.println("⚠️ Error fetching enrollments: " + e.getMessage());
        }
        return courses;
    }
}
