
package com.rohithk.registration.db;

import com.zaxxer.hikari.HikariConfig;
import com.zaxxer.hikari.HikariDataSource;

import java.io.FileInputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.Properties;

public class Database {
    private static HikariDataSource ds;

    public static void init(String propsPath) {
        Properties p = new Properties();
        try (FileInputStream fis = new FileInputStream(propsPath)) {
            p.load(fis);
        } catch (IOException e) {
            throw new RuntimeException("Failed to load db.properties at " + propsPath, e);
        }
        HikariConfig cfg = new HikariConfig();
        cfg.setJdbcUrl(p.getProperty("db.url"));
        cfg.setUsername(p.getProperty("db.user"));
        cfg.setPassword(p.getProperty("db.password"));
        cfg.setMaximumPoolSize(Integer.parseInt(p.getProperty("db.poolSize","10")));
        cfg.setPoolName("RegistrationPool");
        ds = new HikariDataSource(cfg);
    }

    public static Connection getConnection() throws SQLException {
        if (ds == null) throw new IllegalStateException("Database not initialized");
        return ds.getConnection();
    }

    public static void close() {
        if (ds != null) ds.close();
    }
}
