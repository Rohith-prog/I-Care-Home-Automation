
package com.rohithk.registration.service;

import com.rohithk.registration.AppException;
import com.rohithk.registration.dao.StudentDao;
import com.rohithk.registration.model.Student;

import java.sql.SQLException;
import java.util.List;
import java.util.regex.Pattern;

public class StudentService {
    private final StudentDao dao = new StudentDao();
    private final Pattern emailPat = Pattern.compile("^[A-Za-z0-9+_.-]+@(.+)$");

    public Student add(String name, String email) {
        try {
            if (name == null || name.trim().length() < 2) throw new AppException("Name too short");
            if (email == null || !emailPat.matcher(email).matches()) throw new AppException("Invalid email");
            if (dao.findByEmail(email).isPresent()) throw new AppException("Email already exists");
            return dao.add(name, email);
        } catch (SQLException e) {
            throw new AppException("Failed to add student: " + e.getMessage(), e);
        }
    }

    public List<Student> list() {
        try { return dao.list(); }
        catch (SQLException e) { throw new AppException("Failed to list students", e); }
    }
}
