
package com.rohithk.registration.service;

import com.rohithk.registration.AppException;
import com.rohithk.registration.dao.CourseDao;
import com.rohithk.registration.model.Course;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.sql.SQLException;
import java.util.List;
import java.util.Optional;
import java.util.regex.Pattern;

public class CourseService {
    private final CourseDao dao = new CourseDao();
    private final Pattern codePat = Pattern.compile("^[A-Z]{2,4}\d{3}$");

    public Course add(String code, String title, int capacity) {
        try {
            if (code == null || !codePat.matcher(code.toUpperCase()).matches()) throw new AppException("Invalid course code (e.g., CS101)");
            if (title == null || title.trim().length() < 3) throw new AppException("Title too short");
            if (capacity < 1) throw new AppException("Capacity must be >= 1");
            if (dao.findByCode(code).isPresent()) throw new AppException("Course code already exists");
            return dao.add(code, title, capacity);
        } catch (SQLException e) {
            throw new AppException("Failed to add course: " + e.getMessage(), e);
        }
    }

    public List<Course> list() {
        try { return dao.list(); }
        catch (SQLException e) { throw new AppException("Failed to list courses", e); }
    }

    public Optional<Course> byCode(String code) {
        try { return dao.findByCode(code); }
        catch (SQLException e) { throw new AppException("Failed find course", e); }
    }

    public int countEnrollments(int courseId) {
        try { return dao.countEnrollments(courseId); }
        catch (SQLException e) { throw new AppException("Failed count enrollments", e); }
    }

    public int importFromCsv(String path) {
        int added = 0;
        try (BufferedReader br = new BufferedReader(new FileReader(path))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] parts = line.split(",");
                if (parts.length < 3) continue;
                try {
                    add(parts[0].trim(), parts[1].trim(), Integer.parseInt(parts[2].trim()));
                    added++;
                } catch (AppException ex) {
                    // skip invalid rows; continue
                }
            }
            return added;
        } catch (IOException e) {
            throw new AppException("CSV import failed: " + e.getMessage(), e);
        }
    }
}
