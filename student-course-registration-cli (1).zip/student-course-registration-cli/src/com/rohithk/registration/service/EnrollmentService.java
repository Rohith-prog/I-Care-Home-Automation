
package com.rohithk.registration.service;

import com.rohithk.registration.AppException;
import com.rohithk.registration.dao.EnrollmentDao;
import com.rohithk.registration.model.Course;

import java.io.IOException;
import java.sql.SQLException;

public class EnrollmentService {
    private final EnrollmentDao dao = new EnrollmentDao();
    private final CourseService courses = new CourseService();

    public void enroll(int studentId, Course course) {
        try {
            int enrolled = courses.countEnrollments(course.id);
            if (enrolled >= course.capacity) throw new AppException("Course is full");
            dao.enroll(studentId, course.id);
        } catch (SQLException e) {
            if (e instanceof java.sql.SQLIntegrityConstraintViolationException) {
                throw new AppException("Student already enrolled");
            }
            throw new AppException("Enrollment failed: " + e.getMessage(), e);
        }
    }

    public boolean drop(int studentId, int courseId) {
        try { return dao.drop(studentId, courseId); }
        catch (SQLException e) { throw new AppException("Drop failed", e); }
    }

    public void exportReportCsv(String path) {
        try { dao.exportEnrollmentReportCsv(path); }
        catch (SQLException | IOException e) { throw new AppException("Export failed: " + e.getMessage(), e); }
    }
}
