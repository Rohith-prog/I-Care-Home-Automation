
package com.rohithk.registration;

import com.rohithk.registration.db.Database;
import com.rohithk.registration.model.Course;
import com.rohithk.registration.model.Student;
import com.rohithk.registration.service.CourseService;
import com.rohithk.registration.service.EnrollmentService;
import com.rohithk.registration.service.StudentService;
import com.rohithk.registration.util.Input;
import com.rohithk.registration.util.Validators;

import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.List;

public class Main {

    private static final StudentService students = new StudentService();
    private static final CourseService courses = new CourseService();
    private static final EnrollmentService enrollments = new EnrollmentService();

    public static void main(String[] args) {
        String propsPath = "resources/db.properties";
        if (!Files.exists(Paths.get(propsPath))) {
            System.out.println(">> Copy resources/db.properties.sample to resources/db.properties and set your DB creds.");
            return;
        }
        Database.init(propsPath);
        new Main().run();
        Database.close();
    }

    private final Input input = new Input();

    private void run() {
        while (true) {
            System.out.println("\n=== Student Course Registration ===");
            System.out.println("1) Students");
            System.out.println("2) Courses");
            System.out.println("3) Enrollment");
            System.out.println("4) Admin");
            System.out.println("0) Exit");
            String choice = input.prompt("Select");
            switch (choice) {
                case "1": studentsMenu(); break;
                case "2": coursesMenu(); break;
                case "3": enrollmentMenu(); break;
                case "4": adminMenu(); break;
                case "0": return;
                default: System.out.println("Invalid option.");
            }
        }
    }

    private void studentsMenu() {
        System.out.println("\n-- Students --");
        System.out.println("1) Add Student");
        System.out.println("2) List Students");
        String c = input.prompt("Select");
        try {
            if ("1".equals(c)) {
                String name = input.prompt("Name");
                String email = input.prompt("Email");
                Student s = students.add(name, email);
                System.out.println("Added: " + s.id + " " + s.name + " <" + s.email + ">");
            } else if ("2".equals(c)) {
                List<Student> list = students.list();
                list.forEach(s -> System.out.println(s.id + " | " + s.name + " | " + s.email));
            } else System.out.println("Invalid");
        } catch (AppException ex) {
            System.out.println("Error: " + ex.getMessage());
        }
    }

    private void coursesMenu() {
        System.out.println("\n-- Courses --");
        System.out.println("1) Add Course");
        System.out.println("2) List Courses");
        String c = input.prompt("Select");
        try {
            if ("1".equals(c)) {
                String code = input.prompt("Code (e.g., CS101)");
                String title = input.prompt("Title");
                int capacity = Validators.requireInt(input.prompt("Capacity"), "Capacity");
                Course course = courses.add(code, title, capacity);
                System.out.println("Added: " + course.code + " - " + course.title + " (cap " + course.capacity + ")");
            } else if ("2".equals(c)) {
                courses.list().forEach(k -> System.out.println(k.id + " | " + k.code + " | " + k.title + " | cap " + k.capacity));
            } else System.out.println("Invalid");
        } catch (IllegalArgumentException | AppException ex) {
            System.out.println("Error: " + ex.getMessage());
        }
    }

    private void enrollmentMenu() {
        System.out.println("\n-- Enrollment --");
        System.out.println("1) Enroll Student in Course");
        System.out.println("2) Drop Student from Course");
        String c = input.prompt("Select");
        try {
            if ("1".equals(c)) {
                int studentId = Validators.requireInt(input.prompt("Student ID"), "Student ID");
                String code = input.prompt("Course Code");
                Course course = courses.byCode(code).orElseThrow(() -> new AppException("Course not found"));
                enrollments.enroll(studentId, course);
                System.out.println("Enrolled student " + studentId + " in " + course.code);
            } else if ("2".equals(c)) {
                int studentId = Validators.requireInt(input.prompt("Student ID"), "Student ID");
                int courseId = Validators.requireInt(input.prompt("Course ID"), "Course ID");
                boolean ok = enrollments.drop(studentId, courseId);
                System.out.println(ok ? "Dropped." : "No such enrollment.");
            } else System.out.println("Invalid");
        } catch (IllegalArgumentException | AppException ex) {
            System.out.println("Error: " + ex.getMessage());
        }
    }

    private void adminMenu() {
        System.out.println("\n-- Admin --");
        System.out.println("1) Bulk Import Courses from CSV (resources/courses_import.csv)");
        System.out.println("2) Export Enrollment Report CSV (enrollment_report.csv)");
        String c = input.prompt("Select");
        try {
            if ("1".equals(c)) {
                int count = courses.importFromCsv("resources/courses_import.csv");
                System.out.println("Imported courses: " + count);
            } else if ("2".equals(c)) {
                enrollments.exportReportCsv("enrollment_report.csv");
                System.out.println("Report written to enrollment_report.csv");
            } else System.out.println("Invalid");
        } catch (AppException ex) {
            System.out.println("Error: " + ex.getMessage());
        }
    }
}
