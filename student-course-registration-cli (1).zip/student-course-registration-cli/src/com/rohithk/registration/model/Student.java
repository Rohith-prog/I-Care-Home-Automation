
package com.rohithk.registration.model;

public class Student {
    public Integer id;
    public String name;
    public String email;
    public Student(){}
    public Student(Integer id, String name, String email){ this.id=id; this.name=name; this.email=email; }
}
