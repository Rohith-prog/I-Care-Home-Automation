
package com.rohithk.registration.model;

public class Enrollment {
    public Integer id;
    public Integer studentId;
    public Integer courseId;
    public Enrollment(){}
    public Enrollment(Integer id, Integer studentId, Integer courseId){ this.id=id; this.studentId=studentId; this.courseId=courseId; }
}
