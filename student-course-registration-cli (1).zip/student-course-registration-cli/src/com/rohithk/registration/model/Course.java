
package com.rohithk.registration.model;

public class Course {
    public Integer id;
    public String code;
    public String title;
    public Integer capacity;
    public Course(){}
    public Course(Integer id, String code, String title, Integer capacity){ this.id=id; this.code=code; this.title=title; this.capacity=capacity; }
}
