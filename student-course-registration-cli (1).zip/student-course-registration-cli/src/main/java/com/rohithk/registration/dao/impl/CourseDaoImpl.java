
package com.rohithk.registration.dao.impl;

import com.rohithk.registration.dao.CourseDao;
import com.rohithk.registration.db.DB;
import com.rohithk.registration.model.Course;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class CourseDaoImpl implements CourseDao {
    @Override
    public Course create(Course c) {
        String sql = "INSERT INTO courses(code, title, capacity) VALUES(?, ?, ?)";
        try (Connection con = DB.getConnection();
             PreparedStatement ps = con.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            ps.setString(1, c.getCode());
            ps.setString(2, c.getTitle());
            ps.setInt(3, c.getCapacity());
            ps.executeUpdate();
            try (ResultSet rs = ps.getGeneratedKeys()) {
                if (rs.next()) c.setId(rs.getInt(1));
            }
            return c;
        } catch (SQLIntegrityConstraintViolationException dup) {
            throw new RuntimeException("Course code already exists.");
        } catch (SQLException e) {
            throw new RuntimeException("Failed to create course: " + e.getMessage());
        }
    }

    @Override
    public List<Course> list() {
        String sql = "SELECT id, code, title, capacity FROM courses ORDER BY id";
        List<Course> out = new ArrayList<>();
        try (Connection con = DB.getConnection();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                out.add(new Course(rs.getInt("id"), rs.getString("code"),
                        rs.getString("title"), rs.getInt("capacity")));
            }
        } catch (SQLException e) {
            throw new RuntimeException("Failed to list courses: " + e.getMessage());
        }
        return out;
    }

    @Override
    public Optional<Course> findById(int id) {
        String sql = "SELECT id, code, title, capacity FROM courses WHERE id=?";
        try (Connection con = DB.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return Optional.of(new Course(rs.getInt("id"), rs.getString("code"),
                            rs.getString("title"), rs.getInt("capacity")));
                }
                return Optional.empty();
            }
        } catch (SQLException e) {
            throw new RuntimeException("Failed to find course: " + e.getMessage());
        }
    }

    @Override
    public Optional<Course> findByCode(String code) {
        String sql = "SELECT id, code, title, capacity FROM courses WHERE code=?";
        try (Connection con = DB.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, code);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return Optional.of(new Course(rs.getInt("id"), rs.getString("code"),
                            rs.getString("title"), rs.getInt("capacity")));
                }
                return Optional.empty();
            }
        } catch (SQLException e) {
            throw new RuntimeException("Failed to find course: " + e.getMessage());
        }
    }

    @Override
    public int countEnrollments(int courseId) {
        String sql = "SELECT COUNT(*) FROM enrollments WHERE course_id=?";
        try (Connection con = DB.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, courseId);
            try (ResultSet rs = ps.executeQuery()) {
                rs.next();
                return rs.getInt(1);
            }
        } catch (SQLException e) {
            throw new RuntimeException("Failed to count enrollments: " + e.getMessage());
        }
    }
}
