
package com.rohithk.registration.dao;

import com.rohithk.registration.model.Enrollment;
import java.util.List;

public interface EnrollmentDao {
    Enrollment enroll(Enrollment enrollment);
    boolean drop(int studentId, int courseId);
    List<Enrollment> listByStudent(int studentId);
    List<String> roster(int courseId);
    boolean exists(int studentId, int courseId);
}
