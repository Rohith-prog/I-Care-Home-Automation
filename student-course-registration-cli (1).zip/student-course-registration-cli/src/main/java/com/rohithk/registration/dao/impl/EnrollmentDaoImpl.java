
package com.rohithk.registration.dao.impl;

import com.rohithk.registration.dao.EnrollmentDao;
import com.rohithk.registration.db.DB;
import com.rohithk.registration.model.Enrollment;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class EnrollmentDaoImpl implements EnrollmentDao {
    @Override
    public Enrollment enroll(Enrollment e) {
        String sql = "INSERT INTO enrollments(student_id, course_id) VALUES(?, ?)";
        try (Connection con = DB.getConnection();
             PreparedStatement ps = con.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            ps.setInt(1, e.getStudentId());
            ps.setInt(2, e.getCourseId());
            ps.executeUpdate();
            try (ResultSet rs = ps.getGeneratedKeys()) {
                if (rs.next()) e.setId(rs.getInt(1));
            }
            return e;
        } catch (SQLIntegrityConstraintViolationException dup) {
            throw new RuntimeException("Already enrolled.");
        } catch (SQLException ex) {
            throw new RuntimeException("Failed to enroll: " + ex.getMessage());
        }
    }

    @Override
    public boolean drop(int studentId, int courseId) {
        String sql = "DELETE FROM enrollments WHERE student_id=? AND course_id=?";
        try (Connection con = DB.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, studentId);
            ps.setInt(2, courseId);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            throw new RuntimeException("Failed to drop: " + e.getMessage());
        }
    }

    @Override
    public List<Enrollment> listByStudent(int studentId) {
        String sql = "SELECT id, student_id, course_id FROM enrollments WHERE student_id=? ORDER BY id";
        List<Enrollment> out = new ArrayList<>();
        try (Connection con = DB.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, studentId);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    out.add(new Enrollment(rs.getInt("id"), rs.getInt("student_id"), rs.getInt("course_id")));
                }
            }
        } catch (SQLException e) {
            throw new RuntimeException("Failed to list enrollments: " + e.getMessage());
        }
        return out;
    }

    @Override
    public List<String> roster(int courseId) {
        String sql = "SELECT s.id, s.name, s.email FROM enrollments e JOIN students s ON e.student_id=s.id WHERE e.course_id=? ORDER BY s.id";
        List<String> out = new ArrayList<>();
        try (Connection con = DB.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, courseId);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    out.add(String.format("Student{id=%d, name='%s', email='%s'}", rs.getInt(1), rs.getString(2), rs.getString(3)));
                }
            }
        } catch (SQLException e) {
            throw new RuntimeException("Failed to get roster: " + e.getMessage());
        }
        return out;
    }

    @Override
    public boolean exists(int studentId, int courseId) {
        String sql = "SELECT 1 FROM enrollments WHERE student_id=? AND course_id=?";
        try (Connection con = DB.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, studentId);
            ps.setInt(2, courseId);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next();
            }
        } catch (SQLException e) {
            throw new RuntimeException("Failed to check enrollment: " + e.getMessage());
        }
    }
}
