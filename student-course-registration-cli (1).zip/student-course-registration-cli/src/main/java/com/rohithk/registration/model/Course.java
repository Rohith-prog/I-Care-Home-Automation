
package com.rohithk.registration.model;

public class Course {
    private int id;
    private String code;
    private String title;
    private int capacity;

    public Course() {}
    public Course(int id, String code, String title, int capacity) {
        this.id = id;
        this.code = code;
        this.title = title;
        this.capacity = capacity;
    }
    public Course(String code, String title, int capacity) {
        this.code = code;
        this.title = title;
        this.capacity = capacity;
    }
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
    public String getCode() { return code; }
    public void setCode(String code) { this.code = code; }
    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }
    public int getCapacity() { return capacity; }
    public void setCapacity(int capacity) { this.capacity = capacity; }

    @Override
    public String toString() {
        return String.format("Course{id=%d, code='%s', title='%s', capacity=%d}", id, code, title, capacity);
    }
}
