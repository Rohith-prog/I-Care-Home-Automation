
package com.rohithk.registration;

import com.rohithk.registration.service.RegistrationService;
import com.rohithk.registration.util.InputUtil;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        RegistrationService service = new RegistrationService();
        Scanner sc = new Scanner(System.in);
        System.out.println("=== Student Course Registration (CLI) ===");

        while (true) {
            try {
                System.out.println("\n1) Admin Menu  2) Student Menu  0) Exit");
                int choice = InputUtil.readInt(sc, "Choose option: ");
                switch (choice) {
                    case 1:
                        adminMenu(service, sc);
                        break;
                    case 2:
                        studentMenu(service, sc);
                        break;
                    case 0:
                        System.out.println("Goodbye!");
                        return;
                    default:
                        System.out.println("Invalid choice.");
                }
            } catch (Exception e) {
                System.out.println("Error: " + e.getMessage());
            }
        }
    }

    private static void adminMenu(RegistrationService service, Scanner sc) {
        System.out.println("--- Admin Login ---");
        String email = InputUtil.readNonEmpty(sc, "Email: ");
        String password = InputUtil.readNonEmpty(sc, "Password: ");
        if (!service.adminLogin(email, password)) {
            System.out.println("Invalid admin credentials.");
            return;
        }
        while (true) {
            System.out.println("\n--- Admin Menu ---");
            System.out.println("1) Create Course  2) List Courses  3) Create Student  4) List Students  5) View Course Roster  0) Back");
            int c = InputUtil.readInt(sc, "Choose option: ");
            switch (c) {
                case 1:
                    String code = InputUtil.readPattern(sc, "Course code (e.g., CS101): ", "^[A-Za-z0-9_-]{2,20}$", "Invalid code.");
                    String title = InputUtil.readNonEmpty(sc, "Course title: ");
                    int cap = InputUtil.readPositiveInt(sc, "Capacity: ");
                    System.out.println(service.createCourse(code.toUpperCase(), title, cap));
                    break;
                case 2:
                    service.listCourses().forEach(System.out::println);
                    break;
                case 3:
                    String name = InputUtil.readNonEmpty(sc, "Student name: ");
                    String semail = InputUtil.readPattern(sc, "Student email: ", "^[\w._%+-]+@[\w.-]+\.[A-Za-z]{2,}$", "Invalid email.");
                    System.out.println(service.createStudent(name, semail));
                    break;
                case 4:
                    service.listStudents().forEach(System.out::println);
                    break;
                case 5:
                    int courseId = InputUtil.readPositiveInt(sc, "Course ID: ");
                    service.getCourseRoster(courseId).forEach(System.out::println);
                    break;
                case 0:
                    return;
                default:
                    System.out.println("Invalid choice.");
            }
        }
    }

    private static void studentMenu(RegistrationService service, Scanner sc) {
        while (true) {
            System.out.println("\n--- Student Menu ---");
            System.out.println("1) Enroll  2) Drop  3) My Enrollments  4) List Courses  0) Back");
            int c = InputUtil.readInt(sc, "Choose option: ");
            switch (c) {
                case 1:
                    int sid = InputUtil.readPositiveInt(sc, "Student ID: ");
                    int cid = InputUtil.readPositiveInt(sc, "Course ID: ");
                    System.out.println(service.enroll(sid, cid));
                    break;
                case 2:
                    sid = InputUtil.readPositiveInt(sc, "Student ID: ");
                    cid = InputUtil.readPositiveInt(sc, "Course ID: ");
                    System.out.println(service.drop(sid, cid));
                    break;
                case 3:
                    sid = InputUtil.readPositiveInt(sc, "Student ID: ");
                    service.getStudentEnrollments(sid).forEach(System.out::println);
                    break;
                case 4:
                    service.listCourses().forEach(System.out::println);
                    break;
                case 0:
                    return;
                default:
                    System.out.println("Invalid choice.");
            }
        }
    }
}
