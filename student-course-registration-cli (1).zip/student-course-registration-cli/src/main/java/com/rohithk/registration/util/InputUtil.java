
package com.rohithk.registration.util;

import java.util.Scanner;

public class InputUtil {
    public static int readInt(Scanner sc, String prompt) {
        while (true) {
            System.out.print(prompt);
            String s = sc.nextLine();
            try {
                return Integer.parseInt(s.trim());
            } catch (NumberFormatException e) {
                System.out.println("Please enter a valid number.");
            }
        }
    }

    public static int readPositiveInt(Scanner sc, String prompt) {
        while (true) {
            int v = readInt(sc, prompt);
            if (v > 0) return v;
            System.out.println("Please enter a positive number.");
        }
    }

    public static String readNonEmpty(Scanner sc, String prompt) {
        while (true) {
            System.out.print(prompt);
            String s = sc.nextLine();
            if (s != null && !s.trim().isEmpty()) return s.trim();
            System.out.println("This field cannot be empty.");
        }
    }

    public static String readPattern(Scanner sc, String prompt, String regex, String errorMsg) {
        while (true) {
            System.out.print(prompt);
            String s = sc.nextLine();
            if (s != null && s.matches(regex)) return s.trim();
            System.out.println(errorMsg);
        }
    }
}
